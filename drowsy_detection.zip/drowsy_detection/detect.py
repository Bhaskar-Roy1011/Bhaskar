# ============================================================
# DROWSINESS DETECTION SYSTEM
# ============================================================

import cv2
import numpy as np

from tensorflow.keras.models import load_model

from pygame import mixer


# ============================================================
# LOAD MODEL
# ============================================================

model = load_model("drowsy_eye_model.keras")

print("Model Loaded Successfully")


# ============================================================
# INITIALIZE ALARM
# ============================================================

mixer.init()

alarm_sound = mixer.Sound("alarm.wav")


# ============================================================
# LOAD FACE DETECTOR
# ============================================================

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades +
    "haarcascade_frontalface_default.xml"
)


# ============================================================
# START WEBCAM
# ============================================================

cap = cv2.VideoCapture(0)

# drowsiness counter
counter = 0


# ============================================================
# MAIN LOOP
# ============================================================

while True:

    ret, frame = cap.read()

    if not ret:
        break

    # convert to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # detect faces
    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.3,
        minNeighbors=5
    )

    # loop through faces
    for (x, y, w, h) in faces:

        # crop face
        face = gray[y:y+h, x:x+w]

        # resize to model input
        face = cv2.resize(face, (24, 24))

        # normalize
        face = face / 255.0

        # reshape
        face = face.reshape(1, 24, 24, 1)

        # prediction
        prediction = model.predict(face, verbose=0)

        # convert prediction
        prediction_value = prediction[0][0]

        # ====================================================
        # DROWSY
        # ====================================================

        if prediction_value > 0.5:

            state = "DROWSY"

            color = (0, 0, 255)

            counter += 1

        # ====================================================
        # NOT DROWSY
        # ====================================================

        else:

            state = "NOT DROWSY"

            color = (0, 255, 0)

            counter = 0

        # ====================================================
        # PLAY ALARM
        # ====================================================

        if counter > 3:

            alarm_sound.play()

            cv2.putText(
                frame,
                "WAKE UP!",
                (x, y - 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 0, 255),
                3
            )

        # draw rectangle
        cv2.rectangle(
            frame,
            (x, y),
            (x + w, y + h),
            color,
            2
        )

        # show state
        cv2.putText(
            frame,
            state,
            (x, y - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            color,
            2
        )

    # show webcam
    cv2.imshow("Drowsiness Detection", frame)

    # press q to quit
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# ============================================================
# RELEASE
# ============================================================

cap.release()

cv2.destroyAllWindows()